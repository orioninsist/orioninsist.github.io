# Siparis Ozeti

Is adi: orioninsist-wifi-guest-access
Musteri: orioninsist
Paket: Standard - logo QR + CTA frame
QR tipi: wifi
Kullanim alani: guest Wi-Fi
Marka: Orioninsist Wi-Fi Guest Access
Logo: Var
Sablon: Split Label
Frame: split
Logo alani: rounded
CTA: JOIN WIFI
Print preset: Masa menu karti
Test durumu: Auto verified
Revizyon: Yok
Konsept sayisi: 2
Uretim tarihi: 2026-05-04T16:14:27.888Z

## Payload

```text
WIFI:T:WPA;S:ORIONINSIST-GUEST;P:orioninsist2026;H:false;
```

## Teslim Dosyalari

- orioninsist-wifi-guest-access.png
- orioninsist-wifi-guest-access.jpg
- orioninsist-wifi-guest-access.svg
- orioninsist-wifi-guest-access.pdf
- orioninsist-wifi-guest-access-presentation.png
- orioninsist-wifi-guest-access-presentation.pdf
- orioninsist-wifi-guest-access.txt
- order-summary.md
- delivery-message.txt
- verification.md
- customer-brief.md
- quality-checklist.md
- manifest.json
- customer-requirements-template.md
- orioninsist-wifi-guest-access-delivery-package.zip

## Kapsam Disi

- Logo design
- Logo redesign
- Logo vector tracing
- Business card design
- Flyer or brochure design
- Dynamic QR hosting or editable destination management
- AI art QR generation
- Manual Adobe/Canva/Figma editing
- Copywriting for the client's landing page
