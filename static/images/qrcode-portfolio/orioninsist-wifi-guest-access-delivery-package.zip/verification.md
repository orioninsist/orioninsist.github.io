# QR Dogrulama Notu

Durum: Auto verified

Beklenen payload:

```text
WIFI:T:WPA;S:ORIONINSIST-GUEST;P:orioninsist2026;H:false;
```

Okunan payload:

```text
WIFI:T:WPA;S:ORIONINSIST-GUEST;P:orioninsist2026;H:false;
```
