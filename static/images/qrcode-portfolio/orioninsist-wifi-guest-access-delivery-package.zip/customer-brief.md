# Musteri Brief

Bu servis tamamen kod ile uretilir. Adobe, Canva veya manuel editor adimi yoktur.

## Musteriden Alinan Input

- Hedef link/icerik: WIFI:T:WPA;S:ORIONINSIST-GUEST;P:orioninsist2026;H:false;
- QR tipi: wifi
- Logo dosyasi: Yuklendi
- Marka adi: Orioninsist Wi-Fi Guest Access
- Marka rengi: #314155
- CTA yazisi: JOIN WIFI
- Kullanim alani: guest Wi-Fi
- Paket: Standard - logo QR + CTA frame
- Sablon: Split Label
- Print preset: Masa menu karti

## Uretim Kurali

Input dogrulanir, QR payload olusturulur, logo alanina yerlestirilir, secilen kod sablonu ile frame/CTA uygulanir, ciktilar yazilir ve QR otomatik olarak okunur.

## Kapsam Disi

- Logo design
- Logo redesign
- Logo vector tracing
- Business card design
- Flyer or brochure design
- Dynamic QR hosting or editable destination management
- AI art QR generation
- Manual Adobe/Canva/Figma editing
- Copywriting for the client's landing page
