# QR Code Customer Input Template

Please fill this template and send it back with your ready logo file attached.

Important: logo design, logo editing, dynamic QR hosting, later link editing, Adobe/Canva/Figma source files, business card/flyer design, and revision rounds are not included.

## Required Inputs

Job name:
Company / brand name:
QR type: URL
QR destination:
Brand color: #0f8b8d
CTA text: SCAN ME
Use case:
Package: Standard
Template: Clean Logo

## Optional Inputs

QR color:
Background color:
Frame color:
Print preset:
Logo area:
Phone:
Message:
Email:
Subject:
Wi-Fi network name:
Wi-Fi password:
Full name:
Organization:
Title:
Website:
Address:

## Accepted Options

QR type: URL, Text, Phone, SMS, Email, Wi-Fi, WhatsApp, Social link, vCard
Package: Basic, Standard, Premium
Template: Clean Logo, Bold CTA Banner, Premium Badge, Ticket Scan, Minimal Brand, Corner Mark, Split Label, Luxury Line, Social Pop, Menu Plate, Packaging Label, Event Pass
Print preset: Digital / web, Business card 85x55 mm, A5 flyer, A4 poster, Table menu card, Square sticker 100x100 mm
Logo area: Rounded square, Circle, Horizontal badge, Diamond, No white area
