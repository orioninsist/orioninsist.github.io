# QR Dogrulama Notu

Durum: Auto verified

Beklenen payload:

```text
https://orioninsist.org/qrcode/orioninsist-cafe-menu/
```

Okunan payload:

```text
https://orioninsist.org/qrcode/orioninsist-cafe-menu/
```
