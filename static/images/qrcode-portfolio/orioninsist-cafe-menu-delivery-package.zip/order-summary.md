# Siparis Ozeti

Is adi: orioninsist-cafe-menu
Musteri: orioninsist
Paket: Premium - brand-matched delivery pack
QR tipi: url
Kullanim alani: menu
Marka: Orioninsist Cafe Menu
Logo: Var
Sablon: Menu Plate
Frame: menu
Logo alani: rounded
CTA: VIEW MENU
Print preset: A4 poster
Test durumu: Auto verified
Revizyon: Yok
Konsept sayisi: 3
Uretim tarihi: 2026-05-04T16:14:12.583Z

## Payload

```text
https://orioninsist.org/qrcode/orioninsist-cafe-menu/
```

## Teslim Dosyalari

- orioninsist-cafe-menu.png
- orioninsist-cafe-menu.jpg
- orioninsist-cafe-menu.svg
- orioninsist-cafe-menu.pdf
- orioninsist-cafe-menu-presentation.png
- orioninsist-cafe-menu-presentation.pdf
- orioninsist-cafe-menu.txt
- order-summary.md
- delivery-message.txt
- verification.md
- customer-brief.md
- quality-checklist.md
- manifest.json
- customer-requirements-template.md
- orioninsist-cafe-menu-delivery-package.zip

## Kapsam Disi

- Logo design
- Logo redesign
- Logo vector tracing
- Business card design
- Flyer or brochure design
- Dynamic QR hosting or editable destination management
- AI art QR generation
- Manual Adobe/Canva/Figma editing
- Copywriting for the client's landing page
