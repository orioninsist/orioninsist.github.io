# Musteri Brief

Bu servis tamamen kod ile uretilir. Adobe, Canva veya manuel editor adimi yoktur.

## Musteriden Alinan Input

- Hedef link/icerik: ORIONINSIST RSVP
- QR tipi: text
- Logo dosyasi: Yuklendi
- Marka adi: Orioninsist Luxury Invitation QR
- Marka rengi: #2f3b45
- CTA yazisi: RSVP NOW
- Kullanim alani: invitation card
- Paket: Premium - brand-matched delivery pack
- Sablon: Luxury Line
- Print preset: Kartvizit 85x55 mm

## Uretim Kurali

Input dogrulanir, QR payload olusturulur, logo alanina yerlestirilir, secilen kod sablonu ile frame/CTA uygulanir, ciktilar yazilir ve QR otomatik olarak okunur.

## Kapsam Disi

- Logo design
- Logo redesign
- Logo vector tracing
- Business card design
- Flyer or brochure design
- Dynamic QR hosting or editable destination management
- AI art QR generation
- Manual Adobe/Canva/Figma editing
- Copywriting for the client's landing page
