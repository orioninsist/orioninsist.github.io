# QR Dogrulama Notu

Durum: Auto verified

Beklenen payload:

```text
ORIONINSIST RSVP
```

Okunan payload:

```text
ORIONINSIST RSVP
```
