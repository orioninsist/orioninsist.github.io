# Siparis Ozeti

Is adi: orioninsist-luxury-invitation-qr
Musteri: orioninsist
Paket: Premium - brand-matched delivery pack
QR tipi: text
Kullanim alani: invitation card
Marka: Orioninsist Luxury Invitation QR
Logo: Var
Sablon: Luxury Line
Frame: premium
Logo alani: rounded
CTA: RSVP NOW
Print preset: Kartvizit 85x55 mm
Test durumu: Auto verified
Revizyon: Yok
Konsept sayisi: 3
Uretim tarihi: 2026-05-04T16:15:20.378Z

## Payload

```text
ORIONINSIST RSVP
```

## Teslim Dosyalari

- orioninsist-luxury-invitation-qr.png
- orioninsist-luxury-invitation-qr.jpg
- orioninsist-luxury-invitation-qr.svg
- orioninsist-luxury-invitation-qr.pdf
- orioninsist-luxury-invitation-qr-presentation.png
- orioninsist-luxury-invitation-qr-presentation.pdf
- orioninsist-luxury-invitation-qr.txt
- order-summary.md
- delivery-message.txt
- verification.md
- customer-brief.md
- quality-checklist.md
- manifest.json
- customer-requirements-template.md
- orioninsist-luxury-invitation-qr-delivery-package.zip

## Kapsam Disi

- Logo design
- Logo redesign
- Logo vector tracing
- Business card design
- Flyer or brochure design
- Dynamic QR hosting or editable destination management
- AI art QR generation
- Manual Adobe/Canva/Figma editing
- Copywriting for the client's landing page
