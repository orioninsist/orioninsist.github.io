# QR Dogrulama Notu

Durum: Auto verified

Beklenen payload:

```text
https://orioninsist.org/qrcode/
```

Okunan payload:

```text
https://orioninsist.org/qrcode/
```
