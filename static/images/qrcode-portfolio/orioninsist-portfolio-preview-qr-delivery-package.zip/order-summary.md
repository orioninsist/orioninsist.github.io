# Siparis Ozeti

Is adi: orioninsist-portfolio-preview-qr
Musteri: orioninsist
Paket: Premium - brand-matched delivery pack
QR tipi: url
Kullanim alani: portfolio preview
Marka: Orioninsist Portfolio Preview QR
Logo: Var
Sablon: Corner Mark
Frame: corner
Logo alani: pill
CTA: SEE WORK
Print preset: Digital / web
Test durumu: Auto verified
Revizyon: Yok
Konsept sayisi: 3
Uretim tarihi: 2026-05-04T16:14:26.208Z

## Payload

```text
https://orioninsist.org/qrcode/
```

## Teslim Dosyalari

- orioninsist-portfolio-preview-qr.png
- orioninsist-portfolio-preview-qr.jpg
- orioninsist-portfolio-preview-qr.svg
- orioninsist-portfolio-preview-qr.pdf
- orioninsist-portfolio-preview-qr-presentation.png
- orioninsist-portfolio-preview-qr-presentation.pdf
- orioninsist-portfolio-preview-qr.txt
- order-summary.md
- delivery-message.txt
- verification.md
- customer-brief.md
- quality-checklist.md
- manifest.json
- customer-requirements-template.md
- orioninsist-portfolio-preview-qr-delivery-package.zip

## Kapsam Disi

- Logo design
- Logo redesign
- Logo vector tracing
- Business card design
- Flyer or brochure design
- Dynamic QR hosting or editable destination management
- AI art QR generation
- Manual Adobe/Canva/Figma editing
- Copywriting for the client's landing page
