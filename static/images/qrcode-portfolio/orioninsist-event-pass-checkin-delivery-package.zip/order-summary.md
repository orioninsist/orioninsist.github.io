# Siparis Ozeti

Is adi: orioninsist-event-pass-checkin
Musteri: orioninsist
Paket: Premium - brand-matched delivery pack
QR tipi: url
Kullanim alani: event pass
Marka: Orioninsist Event Pass Check-in
Logo: Var
Sablon: Event Pass
Frame: event
Logo alani: rounded
CTA: CHECK IN
Print preset: Kartvizit 85x55 mm
Test durumu: Auto verified
Revizyon: Yok
Konsept sayisi: 3
Uretim tarihi: 2026-05-04T16:17:08.162Z

## Payload

```text
https://orioninsist.org/checkin
```

## Teslim Dosyalari

- orioninsist-event-pass-checkin.png
- orioninsist-event-pass-checkin.jpg
- orioninsist-event-pass-checkin.svg
- orioninsist-event-pass-checkin.pdf
- orioninsist-event-pass-checkin-presentation.png
- orioninsist-event-pass-checkin-presentation.pdf
- orioninsist-event-pass-checkin.txt
- order-summary.md
- delivery-message.txt
- verification.md
- customer-brief.md
- quality-checklist.md
- manifest.json
- customer-requirements-template.md
- orioninsist-event-pass-checkin-delivery-package.zip

## Kapsam Disi

- Logo design
- Logo redesign
- Logo vector tracing
- Business card design
- Flyer or brochure design
- Dynamic QR hosting or editable destination management
- AI art QR generation
- Manual Adobe/Canva/Figma editing
- Copywriting for the client's landing page
