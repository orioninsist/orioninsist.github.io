# QR Dogrulama Notu

Durum: Auto verified

Beklenen payload:

```text
https://orioninsist.org/checkin
```

Okunan payload:

```text
https://orioninsist.org/checkin
```
