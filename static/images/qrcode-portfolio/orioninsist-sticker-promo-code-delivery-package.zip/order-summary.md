# Siparis Ozeti

Is adi: orioninsist-sticker-promo-code
Musteri: orioninsist
Paket: Standard - logo QR + CTA frame
QR tipi: url
Kullanim alani: promo sticker
Marka: Orioninsist Sticker Promo Code
Logo: Var
Sablon: Ticket Scan
Frame: ticket
Logo alani: rounded
CTA: GET OFFER
Print preset: Kare sticker 100x100 mm
Test durumu: Auto verified
Revizyon: Yok
Konsept sayisi: 2
Uretim tarihi: 2026-05-04T16:14:23.205Z

## Payload

```text
https://orioninsist.org/qrcode/orioninsist-sticker-promo-code/
```

## Teslim Dosyalari

- orioninsist-sticker-promo-code.png
- orioninsist-sticker-promo-code.jpg
- orioninsist-sticker-promo-code.svg
- orioninsist-sticker-promo-code.pdf
- orioninsist-sticker-promo-code-presentation.png
- orioninsist-sticker-promo-code-presentation.pdf
- orioninsist-sticker-promo-code.txt
- order-summary.md
- delivery-message.txt
- verification.md
- customer-brief.md
- quality-checklist.md
- manifest.json
- customer-requirements-template.md
- orioninsist-sticker-promo-code-delivery-package.zip

## Kapsam Disi

- Logo design
- Logo redesign
- Logo vector tracing
- Business card design
- Flyer or brochure design
- Dynamic QR hosting or editable destination management
- AI art QR generation
- Manual Adobe/Canva/Figma editing
- Copywriting for the client's landing page
