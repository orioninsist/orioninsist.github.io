# Siparis Ozeti

Is adi: orioninsist-whatsapp-lead-card
Musteri: orioninsist
Paket: Standard - logo QR + CTA frame
QR tipi: url
Kullanim alani: WhatsApp lead capture
Marka: Orioninsist WhatsApp Lead Card
Logo: Var
Sablon: Bold CTA Banner
Frame: banner
Logo alani: pill
CTA: CHAT NOW
Print preset: Digital / web
Test durumu: Auto verified
Revizyon: Yok
Konsept sayisi: 2
Uretim tarihi: 2026-05-04T16:14:14.096Z

## Payload

```text
https://wa.me/905551112233
```

## Teslim Dosyalari

- orioninsist-whatsapp-lead-card.png
- orioninsist-whatsapp-lead-card.jpg
- orioninsist-whatsapp-lead-card.svg
- orioninsist-whatsapp-lead-card.pdf
- orioninsist-whatsapp-lead-card-presentation.png
- orioninsist-whatsapp-lead-card-presentation.pdf
- orioninsist-whatsapp-lead-card.txt
- order-summary.md
- delivery-message.txt
- verification.md
- customer-brief.md
- quality-checklist.md
- manifest.json
- customer-requirements-template.md
- orioninsist-whatsapp-lead-card-delivery-package.zip

## Kapsam Disi

- Logo design
- Logo redesign
- Logo vector tracing
- Business card design
- Flyer or brochure design
- Dynamic QR hosting or editable destination management
- AI art QR generation
- Manual Adobe/Canva/Figma editing
- Copywriting for the client's landing page
