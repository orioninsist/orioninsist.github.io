# Musteri Brief

Bu servis tamamen kod ile uretilir. Adobe, Canva veya manuel editor adimi yoktur.

## Musteriden Alinan Input

- Hedef link/icerik: https://wa.me/905551112233
- QR tipi: url
- Logo dosyasi: Yuklendi
- Marka adi: Orioninsist WhatsApp Lead Card
- Marka rengi: #14b8a6
- CTA yazisi: CHAT NOW
- Kullanim alani: WhatsApp lead capture
- Paket: Standard - logo QR + CTA frame
- Sablon: Bold CTA Banner
- Print preset: Digital / web

## Uretim Kurali

Input dogrulanir, QR payload olusturulur, logo alanina yerlestirilir, secilen kod sablonu ile frame/CTA uygulanir, ciktilar yazilir ve QR otomatik olarak okunur.

## Kapsam Disi

- Logo design
- Logo redesign
- Logo vector tracing
- Business card design
- Flyer or brochure design
- Dynamic QR hosting or editable destination management
- AI art QR generation
- Manual Adobe/Canva/Figma editing
- Copywriting for the client's landing page
