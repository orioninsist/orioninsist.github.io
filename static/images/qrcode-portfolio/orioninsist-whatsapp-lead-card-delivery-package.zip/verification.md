# QR Dogrulama Notu

Durum: Auto verified

Beklenen payload:

```text
https://wa.me/905551112233
```

Okunan payload:

```text
https://wa.me/905551112233
```
