# Musteri Brief

Bu servis tamamen kod ile uretilir. Adobe, Canva veya manuel editor adimi yoktur.

## Musteriden Alinan Input

- Hedef link/icerik: https://orioninsist.org/contact/
- QR tipi: url
- Logo dosyasi: Yuklendi
- Marka adi: Orioninsist Social Profile QR
- Marka rengi: #db2777
- CTA yazisi: FOLLOW US
- Kullanim alani: social media profile
- Paket: Standard - logo QR + CTA frame
- Sablon: Social Pop
- Print preset: Digital / web

## Uretim Kurali

Input dogrulanir, QR payload olusturulur, logo alanina yerlestirilir, secilen kod sablonu ile frame/CTA uygulanir, ciktilar yazilir ve QR otomatik olarak okunur.

## Kapsam Disi

- Logo design
- Logo redesign
- Logo vector tracing
- Business card design
- Flyer or brochure design
- Dynamic QR hosting or editable destination management
- AI art QR generation
- Manual Adobe/Canva/Figma editing
- Copywriting for the client's landing page
