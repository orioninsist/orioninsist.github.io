# Siparis Ozeti

Is adi: orioninsist-social-profile-qr
Musteri: orioninsist
Paket: Standard - logo QR + CTA frame
QR tipi: url
Kullanim alani: social media profile
Marka: Orioninsist Social Profile QR
Logo: Var
Sablon: Social Pop
Frame: social
Logo alani: circle
CTA: FOLLOW US
Print preset: Digital / web
Test durumu: Auto verified
Revizyon: Yok
Konsept sayisi: 2
Uretim tarihi: 2026-05-04T16:14:19.413Z

## Payload

```text
https://orioninsist.org/contact/
```

## Teslim Dosyalari

- orioninsist-social-profile-qr.png
- orioninsist-social-profile-qr.jpg
- orioninsist-social-profile-qr.svg
- orioninsist-social-profile-qr.pdf
- orioninsist-social-profile-qr-presentation.png
- orioninsist-social-profile-qr-presentation.pdf
- orioninsist-social-profile-qr.txt
- order-summary.md
- delivery-message.txt
- verification.md
- customer-brief.md
- quality-checklist.md
- manifest.json
- customer-requirements-template.md
- orioninsist-social-profile-qr-delivery-package.zip

## Kapsam Disi

- Logo design
- Logo redesign
- Logo vector tracing
- Business card design
- Flyer or brochure design
- Dynamic QR hosting or editable destination management
- AI art QR generation
- Manual Adobe/Canva/Figma editing
- Copywriting for the client's landing page
