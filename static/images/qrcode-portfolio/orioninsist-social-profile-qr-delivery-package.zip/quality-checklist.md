# Kalite Kontrol Checklist

- [x] Payload olusturuldu
- [x] QR otomatik okuma testi yapildi
- [x] Logo alani secildi
- [x] CTA/frame sablonu uygulandi
- [x] Marka rengi uygulandi
- [x] PNG cikti hazir
- [x] JPG cikti hazir
- [x] SVG cikti hazir
- [x] PDF cikti hazir
- [x] Sunum PNG cikti hazir
- [x] Sunum PDF cikti hazir
- [x] ZIP teslim paketi hazir

## Dogrulama

Durum: Auto verified

Beklenen payload:

```text
https://orioninsist.org/contact/
```

Okunan payload:

```text
https://orioninsist.org/contact/
```
