# QR Dogrulama Notu

Durum: Auto verified

Beklenen payload:

```text
https://orioninsist.org/contact/
```

Okunan payload:

```text
https://orioninsist.org/contact/
```
