# Siparis Ozeti

Is adi: orioninsist-minimal-business-card
Musteri: orioninsist
Paket: Basic - logo QR
QR tipi: url
Kullanim alani: business card
Marka: Orioninsist Minimal Business Card
Logo: Var
Sablon: Minimal Brand
Frame: minimal
Logo alani: rounded
CTA: CONTACT ME
Print preset: Kartvizit 85x55 mm
Test durumu: Auto verified
Revizyon: Yok
Konsept sayisi: 1
Uretim tarihi: 2026-05-04T16:14:24.446Z

## Payload

```text
https://orioninsist.org/contact/
```

## Teslim Dosyalari

- orioninsist-minimal-business-card.png
- orioninsist-minimal-business-card.jpg
- orioninsist-minimal-business-card.svg
- orioninsist-minimal-business-card.pdf
- orioninsist-minimal-business-card-presentation.png
- orioninsist-minimal-business-card-presentation.pdf
- orioninsist-minimal-business-card.txt
- order-summary.md
- delivery-message.txt
- verification.md
- customer-brief.md
- quality-checklist.md
- manifest.json
- customer-requirements-template.md
- orioninsist-minimal-business-card-delivery-package.zip

## Kapsam Disi

- Logo design
- Logo redesign
- Logo vector tracing
- Business card design
- Flyer or brochure design
- Dynamic QR hosting or editable destination management
- AI art QR generation
- Manual Adobe/Canva/Figma editing
- Copywriting for the client's landing page
