# Musteri Brief

Bu servis tamamen kod ile uretilir. Adobe, Canva veya manuel editor adimi yoktur.

## Musteriden Alinan Input

- Hedef link/icerik: https://orioninsist.org/contact/
- QR tipi: url
- Logo dosyasi: Yuklendi
- Marka adi: Orioninsist Minimal Business Card
- Marka rengi: #202124
- CTA yazisi: CONTACT ME
- Kullanim alani: business card
- Paket: Basic - logo QR
- Sablon: Minimal Brand
- Print preset: Kartvizit 85x55 mm

## Uretim Kurali

Input dogrulanir, QR payload olusturulur, logo alanina yerlestirilir, secilen kod sablonu ile frame/CTA uygulanir, ciktilar yazilir ve QR otomatik olarak okunur.

## Kapsam Disi

- Logo design
- Logo redesign
- Logo vector tracing
- Business card design
- Flyer or brochure design
- Dynamic QR hosting or editable destination management
- AI art QR generation
- Manual Adobe/Canva/Figma editing
- Copywriting for the client's landing page
