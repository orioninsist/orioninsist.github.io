# QR Dogrulama Notu

Durum: Auto verified

Beklenen payload:

```text
ORIONINSIST PRODUCT
```

Okunan payload:

```text
ORIONINSIST PRODUCT
```
