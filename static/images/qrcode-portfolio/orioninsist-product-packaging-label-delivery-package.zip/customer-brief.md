# Musteri Brief

Bu servis tamamen kod ile uretilir. Adobe, Canva veya manuel editor adimi yoktur.

## Musteriden Alinan Input

- Hedef link/icerik: ORIONINSIST PRODUCT
- QR tipi: text
- Logo dosyasi: Yuklendi
- Marka adi: Orioninsist Product Packaging Label
- Marka rengi: #4f6f52
- CTA yazisi: SCAN STORY
- Kullanim alani: packaging
- Paket: Premium - brand-matched delivery pack
- Sablon: Packaging Label
- Print preset: Kare sticker 100x100 mm

## Uretim Kurali

Input dogrulanir, QR payload olusturulur, logo alanina yerlestirilir, secilen kod sablonu ile frame/CTA uygulanir, ciktilar yazilir ve QR otomatik olarak okunur.

## Kapsam Disi

- Logo design
- Logo redesign
- Logo vector tracing
- Business card design
- Flyer or brochure design
- Dynamic QR hosting or editable destination management
- AI art QR generation
- Manual Adobe/Canva/Figma editing
- Copywriting for the client's landing page
