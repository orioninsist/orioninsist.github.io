# Siparis Ozeti

Is adi: orioninsist-product-packaging-label
Musteri: orioninsist
Paket: Premium - brand-matched delivery pack
QR tipi: text
Kullanim alani: packaging
Marka: Orioninsist Product Packaging Label
Logo: Var
Sablon: Packaging Label
Frame: packaging
Logo alani: rounded
CTA: SCAN STORY
Print preset: Kare sticker 100x100 mm
Test durumu: Auto verified
Revizyon: Yok
Konsept sayisi: 3
Uretim tarihi: 2026-05-04T16:17:26.875Z

## Payload

```text
ORIONINSIST PRODUCT
```

## Teslim Dosyalari

- orioninsist-product-packaging-label.png
- orioninsist-product-packaging-label.jpg
- orioninsist-product-packaging-label.svg
- orioninsist-product-packaging-label.pdf
- orioninsist-product-packaging-label-presentation.png
- orioninsist-product-packaging-label-presentation.pdf
- orioninsist-product-packaging-label.txt
- order-summary.md
- delivery-message.txt
- verification.md
- customer-brief.md
- quality-checklist.md
- manifest.json
- customer-requirements-template.md
- orioninsist-product-packaging-label-delivery-package.zip

## Kapsam Disi

- Logo design
- Logo redesign
- Logo vector tracing
- Business card design
- Flyer or brochure design
- Dynamic QR hosting or editable destination management
- AI art QR generation
- Manual Adobe/Canva/Figma editing
- Copywriting for the client's landing page
